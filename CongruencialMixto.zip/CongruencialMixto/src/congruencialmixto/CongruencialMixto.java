/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package congruencialmixto;
import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author cluster
 */
public class CongruencialMixto {
    public static void main(String[] arg) {
       
        double a, c ;
        int xn=0,X0, m;
        double xn1=0;
        double nf=0;
        DecimalFormat formato1 = new DecimalFormat("0.00");
        
        Scanner num = new Scanner(System.in);
        System.out.println("Ingrese Constante Multiplicativa 'a'");
        a = num.nextDouble();
        System.out.println("Ingrese Costante Aditiva 'c'");
        c = num.nextDouble();
        System.out.println("Ingrese semilla 'X0'");
        X0 = num.nextInt();
        System.out.println("Ingrese modulo 'm'");
        m = num.nextInt();
        
        System.out.println("n "+"|" +" Xn"+"  |"+" (aXn+c)m"+ "  |" +" Xn+1"+"   |"+ "# Uniforme");
        for(int i=0; i<8; i++){
           xn1= ((a*X0)+c)/m; 
                   
           xn= (int)((a*X0)+c)%m;
           
           nf=(double)xn/m;
           
           System.out.println(i+" | "+ X0 + "   |  "+ formato1.format(xn1)  +"     |  " +xn+ "     | "  +formato1.format(nf));
           
           X0=xn;
                
       
        }
       
   
    }    

}
    

